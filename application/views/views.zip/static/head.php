<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo $title; ?></title>
        <link href="<?php echo base_url ?>assets/template/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo base_url ?>assets/template/font-awesome/css/font-awesome.css" rel="stylesheet">
        <link href="<?php echo base_url ?>assets/template/css/animate.css" rel="stylesheet">
        <link href="<?php echo base_url ?>assets/template/css/style.css" rel="stylesheet">
        <link href="<?php echo base_url ?>assets/template/css/plugins/steps/jquery.steps.css" rel="stylesheet">
        <link href="<?php echo base_url ?>assets/template/css/plugins/iCheck/custom.css" rel="stylesheet">
        <link href="<?php echo base_url ?>assets/template/css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css" rel="stylesheet">
        <link href="<?php echo base_url ?>assets/template/css/plugins/dataTables/datatables.min.css" rel="stylesheet">
        <!-- Toastr style -->
        <link href="<?php echo base_url ?>assets/template/css/plugins/toastr/toastr.min.css" rel="stylesheet">

        <!-- Gritter -->
        <link href="<?php echo base_url ?>assets/template/js/plugins/gritter/jquery.gritter.css" rel="stylesheet">




    </head>