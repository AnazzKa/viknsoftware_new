<div class="footer">
            <div>
                <strong>Copyright</strong> Vikn &copy;
            </div>
        </div>
        </div>
        
    </div>
    