<?php $User_type = $this->session->userdata("TYPE"); ?>
<div class="wrapper wrapper-content">
    <div class="row">

        <div class="col-md-12">
            <p><B>Wallet</B></p>
        </div>




<div class="col-lg-3">
    <a  href="<?php echo base_url ?>supplier_cards?sup=1">
        <div class="ibox float-e-margins">
            <div class="ibox-title">
                        <span class="label label-success pull-right">
                            BAl : 2323
                        </span>
                <h5>Supplier</h5>
            </div>
    </a>

</div>

</div>
    <div class="col-lg-3">
    <a  href="<?php echo base_url ?>supplier_cards?sup=1">
        <div class="ibox float-e-margins">
            <div class="ibox-title">
                        <span class="label label-success pull-right">
                            BAl : 2323
                        </span>
                <h5>Supplier</h5>
            </div>
    </a>

</div>

</div>
<div class="col-lg-3">
    <a  href="<?php echo base_url ?>supplier_cards?sup=1">
        <div class="ibox float-e-margins">
            <div class="ibox-title">
                        <span class="label label-success pull-right">
                            BAl : 2323
                        </span>
                <h5>Supplier</h5>
            </div>
    </a>

</div>

</div>






<div class="col-lg-3">
    <div id="index" class="collapse out">
        <div class="panel panel-default">






<!--            <a href="">-->
<!--                <div class="panel-body">-->
<!--                    ADD Advertisement<i class="fa fa-chevron-right" style="float: right;"></i>-->
<!--                </div>-->
<!--            </a>-->


        </div>
    </div>
    <a data-toggle="collapse" data-target="#index" href="#index">
        <div class="ibox float-e-margins">
            <button type="button" class="btn btn-info btn-circle btn-xl pull-right"><i class="glyphicon glyphicon-plus"></i></button>
        </div>
    </a>
</div>







</div>




</div>


