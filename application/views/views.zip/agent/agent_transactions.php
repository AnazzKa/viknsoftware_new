<?php $User_type = $this->session->userdata("TYPE"); ?>
<div class="wrapper wrapper-content">
    <div class="row">

        <div class="col-md-12">

            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>ANAS</h5>
                </div>

            </div>
        </div>
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-content">
                    <div>

                                        <span class="pull-right text-right">
                                             <h3 class="font-bold no-margins">
                                                 2017-2018
                                             </h3><br/>
                                        <small>250.00</small><br/>
                                        <small><strong>APPLE SOUK</strong></small>
                                            <br/>
                                           <small>Sales</small><br/>
                                           <small>INV2127</small>
                                        </span>
                        <h3 class="font-bold no-margins">
                            Years
                        </h3><br/>
                        <small>14 Dec 17</small> <br/>
                        <small>Sales</small> <br/>
                        <small>AJWATALK : <b>10.00 </b>nos X <b>25.00</b></small> <br/><br/>
                        <small>
                            <a class="btn btn-danger btn-rounded btn-outline" href="#">UNPAID</a>
                        </small>
                    </div>
                    <hr>

                    <div>
                                        <span class="pull-right text-right">
                                        <small>250.00</small><br/>
                                        <small><strong>APPLE SOUK</strong></small>
                                            <br/>
                                           <small>Cash</small><br/>
                                           <small>INV2127</small>
                                        </span>
                        <small>14 Dec 17</small> <br/>
                        <small>Receipts</small> <br/>
                        <small>
                            &nbsp;&nbsp;<br>
                        </small>
                    </div>
                    <hr>
                    <br/>
                    <div>
                                        <span class="pull-right text-right">
                                        <small>250.00</small><br/>
                                        <small><strong>APPLE SOUK</strong></small>
                                            <br/>
                                           <small>Sales</small><br/>
                                           <small>INV2127</small>
                                        </span>
                        <small>14 Dec 17</small> <br/>
                        <small>Sales</small> <br/>
                        <small>AJWATALK : <b>10.00 </b>nos X <b>25.00</b></small> <br/><br/>
                        <small>
                            <a class="btn btn-danger btn-rounded btn-outline" href="#">UNPAID</a>
                        </small>
                    </div>
                    <hr>
                </div>

            </div>
        </div>